<?php
// sitemap.php
require_once $_SERVER['DOCUMENT_ROOT'] . '/config/database.php';

// Set the header to XML so search engines recognize it
header("Content-Type: application/xml; charset=utf-8");

echo '<?xml version="1.0" encoding="UTF-8"?>';
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

$base_url = "https://" . $_SERVER['HTTP_HOST'];

// 1. Static Pages (Home, Register, etc.)
$static_pages = ['/', '/login', '/register'];
foreach ($static_pages as $page) {
    echo '<url>
            <loc>' . $base_url . $page . '</loc>
            <changefreq>daily</changefreq>
            <priority>1.0</priority>
          </url>';
}

// 2. Dynamic Wiki Articles
$stmt = $pdo->query("SELECT slug, updated_at FROM articles ORDER BY updated_at DESC");
while ($row = $stmt->fetch()) {
    $lastmod = date('Y-m-d', strtotime($row['updated_at']));
    echo '<url>
            <loc>' . $base_url . '/wiki/' . $row['slug'] . '</loc>
            <lastmod>' . $lastmod . '</lastmod>
            <changefreq>weekly</changefreq>
            <priority>0.8</priority>
          </url>';
}

// 3. Categories
$cat_stmt = $pdo->query("SELECT slug FROM categories");
while ($cat = $cat_stmt->fetch()) {
    echo '<url>
            <loc>' . $base_url . '/category/' . $cat['slug'] . '</loc>
            <changefreq>weekly</changefreq>
            <priority>0.5</priority>
          </url>';
}

// 4. User Profiles (Optional, but good for community SEO)
$user_stmt = $pdo->query("SELECT username FROM users LIMIT 100");
while ($user = $user_stmt->fetch()) {
    echo '<url>
            <loc>' . $base_url . '/user/' . $user['username'] . '</loc>
            <changefreq>monthly</changefreq>
            <priority>0.3</priority>
          </url>';
}

echo '</urlset>';
?>
