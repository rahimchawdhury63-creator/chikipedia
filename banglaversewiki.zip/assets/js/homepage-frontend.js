// ==========================================================================
// BanglaVerseWiki - Ultimate Interactive Scripts
// ==========================================================================

document.addEventListener('DOMContentLoaded', () => {
    
    // --- 1. Dynamic Mobile Navigation Menu ---
    // Fixes the header for mobile devices automatically
    const nav = document.querySelector('nav .flex.justify-between');
    const navLinks = document.querySelector('nav .flex.items-center.space-x-4');
    
    if (nav && navLinks) {
        navLinks.classList.add('nav-links-container'); // Add class for CSS targeting
        
        // Create Hamburger Button
        const burgerBtn = document.createElement('button');
        burgerBtn.innerHTML = '<i class="fa-solid fa-bars text-2xl text-blue-700"></i>';
        burgerBtn.className = 'md:hidden block focus:outline-none';
        
        // Insert it into the nav
        nav.appendChild(burgerBtn);
        
        // Toggle Logic
        burgerBtn.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            // Switch icon between bars and X
            if(navLinks.classList.contains('active')) {
                burgerBtn.innerHTML = '<i class="fa-solid fa-xmark text-2xl text-blue-700"></i>';
            } else {
                burgerBtn.innerHTML = '<i class="fa-solid fa-bars text-2xl text-blue-700"></i>';
            }
        });
    }

    // --- 2. Scroll Fade-Up Animations ---
    // Makes cards and main elements load beautifully
    const observerOptions = { threshold: 0.1, rootMargin: "0px 0px -50px 0px" };
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-up-element');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // Apply to main container, aside, and grid cards
    document.querySelectorAll('main, aside > div, .grid > div').forEach(el => {
        el.style.opacity = '0'; // Hide initially
        observer.observe(el);
    });

    // --- 3. Reading Progress Bar & Table of Contents ---
    const wikiContent = document.querySelector('.wiki-content');
    if (wikiContent) {
        // Progress Bar
        const progressBar = document.createElement('div');
        progressBar.id = 'reading-progress';
        document.body.prepend(progressBar);

        window.addEventListener('scroll', () => {
            const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
            const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
            const scrolled = (winScroll / height) * 100;
            progressBar.style.width = scrolled + '%';
        });

        // Auto Generate Table of Contents (TOC)
        const headings = wikiContent.querySelectorAll('h2, h3');
        if (headings.length >= 2) {
            const tocContainer = document.createElement('div');
            tocContainer.className = 'bg-gray-50 border border-gray-200 p-5 rounded-xl mb-8 float-right ml-6 w-full md:w-72 shadow-sm';
            tocContainer.innerHTML = '<h4 class="font-bold text-lg mb-3 border-b pb-2 text-gray-800"><i class="fa-solid fa-list-ul mr-2 text-blue-600"></i> Contents</h4>';
            
            const list = document.createElement('ul');
            list.className = 'space-y-2 text-sm';

            headings.forEach((heading) => {
                if (!heading.id) {
                    heading.id = heading.innerText.toLowerCase().replace(/[^a-z0-9]+/g, '-');
                }
                const li = document.createElement('li');
                li.style.marginLeft = heading.tagName === 'H3' ? '1.5rem' : '0';
                
                const a = document.createElement('a');
                a.href = '#' + heading.id;
                a.innerText = heading.innerText;
                a.className = 'text-gray-600 hover:text-blue-600 hover:underline transition-colors block';
                
                li.appendChild(a);
                list.appendChild(li);
            });

            tocContainer.appendChild(list);
            wikiContent.insertBefore(tocContainer, wikiContent.firstChild);
        }
    }

    // --- 4. Auto-dismiss Alerts ---
    // Smoothly removes error/success messages after 5 seconds
    const alerts = document.querySelectorAll('.bg-red-100, .bg-green-100');
    alerts.forEach(alert => {
        alert.style.position = 'relative';
        const closeBtn = document.createElement('span');
        closeBtn.innerHTML = '&times;';
        closeBtn.style.cssText = 'position:absolute; right:12px; top:8px; cursor:pointer; font-weight:bold; font-size:1.5rem; opacity:0.6; transition:0.3s;';
        closeBtn.onmouseover = () => closeBtn.style.opacity = '1';
        closeBtn.onmouseleave = () => closeBtn.style.opacity = '0.6';
        
        closeBtn.onclick = () => {
            alert.style.transition = 'all 0.4s ease';
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-10px)';
            setTimeout(() => alert.remove(), 400);
        };
        alert.appendChild(closeBtn);

        setTimeout(() => {
            if(document.body.contains(alert)) closeBtn.click();
        }, 5000);
    });
});
