    </div> <footer class="bg-white border-t mt-20 py-10">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <p class="text-gray-600 font-bold mb-2">BanglaVerseWiki</p>
            <div class="flex justify-center space-x-6 text-sm text-gray-500 mb-6">
                <a href="/" class="hover:underline">Home</a>
                <a href="/register" class="hover:underline">Join Us</a>
                <a href="#" class="hover:underline">Privacy Policy</a>
            </div>
            <p class="text-xs text-gray-400">&copy; <?= date('Y') ?> BanglaVerseWiki. Built for knowledge.</p>
        </div>
    </footer>
    
<script src="https://banglaversewiki.unaux.com/assets/js/homepage-frontend.js"></script>
<script src="/assets/js/login-register-other-page.js"></script>
<script src="/assets/js/other.js"></script>
</body>
</html>
