<?php
// config/database.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$host = 'sql311.ezyro.com'; 
$db   = 'ezyro_41451625_banglaverse_db';
$user = 'ezyro_41451625'; 
$pass = 'cd113a10e25f'; 
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // For production, log this instead of displaying it.
    die("Database connection failed. Please try again later.");
}
?>
