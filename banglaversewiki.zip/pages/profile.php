<?php
// pages/profile.php
require_once $_SERVER['DOCUMENT_ROOT'] . '/config/database.php';

$requested_user = isset($_GET['username']) ? htmlspecialchars($_GET['username']) : '';

// 1. Fetch User Basic Info
$stmt = $pdo->prepare("SELECT id, username, email, created_at FROM users WHERE username = ?");
$stmt->execute([$requested_user]);
$user = $stmt->fetch();

if (!$user) {
    $page_title = "User Not Found";
    require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/header.php';
    echo "<div class='text-center py-20'><h1 class='text-4xl font-bold'>User Not Found</h1><p>The user '@$requested_user' does not exist in our database.</p></div>";
    require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php';
    exit;
}

// 2. Fetch User Stats
// Count total edits (revisions)
$edit_count_stmt = $pdo->prepare("SELECT COUNT(*) FROM revisions WHERE user_id = ?");
$edit_count_stmt->execute([$user['id']]);
$total_edits = $edit_count_stmt->fetchColumn();

// Count articles created (where they made the first revision)
$created_stmt = $pdo->prepare("
    SELECT COUNT(*) FROM articles a 
    JOIN revisions r ON a.id = r.article_id 
    WHERE r.user_id = ? AND r.id = (SELECT MIN(id) FROM revisions WHERE article_id = a.id)
");
$created_stmt->execute([$user['id']]);
$articles_created = $created_stmt->fetchColumn();

// Calculate "Impact" (Total views on articles they've edited)
$impact_stmt = $pdo->prepare("
    SELECT SUM(a.views) as total_views, SUM(a.likes) as total_likes 
    FROM articles a
    JOIN revisions r ON a.id = r.article_id
    WHERE r.user_id = ?
");
$impact_stmt->execute([$user['id']]);
$impact = $impact_stmt->fetch();

// 3. Fetch Recent Contributions
$contrib_stmt = $pdo->prepare("
    SELECT DISTINCT a.title, a.slug, r.created_at 
    FROM articles a
    JOIN revisions r ON a.id = r.article_id
    WHERE r.user_id = ?
    ORDER BY r.created_at DESC
    LIMIT 10
");
$contrib_stmt->execute([$user['id']]);
$contributions = $contrib_stmt->fetchAll();

$page_title = $user['username'] . "'s Profile - BanglaVerseWiki";
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/header.php';
?>

<div class="max-w-4xl mx-auto">
    <div class="profile-header rounded-lg p-8 text-white mb-8 shadow-lg">
        <div class="flex items-center space-x-6">
            <div class="w-24 h-24 bg-white text-blue-600 rounded-full flex items-center justify-center text-4xl font-bold border-4 border-blue-200">
                <?= strtoupper(substr($user['username'], 0, 1)) ?>
            </div>
            <div>
                <h1 class="text-3xl font-bold">@<?= htmlspecialchars($user['username']) ?></h1>
                <p class="opacity-80">Member since: <?= date('M Y', strtotime($user['created_at'])) ?></p>
                <div class="mt-2 flex space-x-2">
                    <span class="user-badge text-blue-800 bg-blue-100">Editor</span>
                    <?php if($total_edits > 50): ?>
                        <span class="user-badge text-yellow-800 bg-yellow-100">Gold Contributor</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8 text-center">
        <div class="bg-white p-6 rounded shadow border">
            <p class="text-gray-500 text-sm uppercase font-bold">Total Edits</p>
            <p class="text-3xl font-bold text-blue-600"><?= $total_edits ?></p>
        </div>
        <div class="bg-white p-6 rounded shadow border">
            <p class="text-gray-500 text-sm uppercase font-bold">Articles Created</p>
            <p class="text-3xl font-bold text-green-600"><?= $articles_created ?></p>
        </div>
        <div class="bg-white p-6 rounded shadow border">
            <p class="text-gray-500 text-sm uppercase font-bold">Total Impact (Views)</p>
            <p class="text-3xl font-bold text-purple-600"><?= number_format($impact['total_views'] ?? 0) ?></p>
        </div>
    </div>

    <div class="bg-white rounded shadow border overflow-hidden">
        <div class="bg-gray-50 px-6 py-4 border-b">
            <h2 class="font-bold text-xl text-gray-800">Recent Contributions</h2>
        </div>
        <div class="divide-y">
            <?php if(empty($contributions)): ?>
                <p class="p-6 text-gray-500 text-center">This user hasn't made any edits yet.</p>
            <?php else: ?>
                <?php foreach($contributions as $c): ?>
                    <div class="p-6 flex justify-between items-center hover:bg-gray-50 transition">
                        <div>
                            <a href="/wiki/<?= $c['slug'] ?>" class="text-lg font-bold text-blue-600 hover:underline">
                                <?= htmlspecialchars($c['title']) ?>
                            </a>
                            <p class="text-xs text-gray-400 mt-1">
                                Edited on <?= date('F j, Y', strtotime($c['created_at'])) ?>
                            </p>
                        </div>
                        <a href="/wiki/<?= $c['slug'] ?>" class="text-gray-400 hover:text-blue-600">
                            <i class="fa-solid fa-arrow-right"></i>
                        </a>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php 
// Include sidebar for balance
echo "</div>"; // Close main tag
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/sidebar.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php'; 
?>
