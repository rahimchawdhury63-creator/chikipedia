<?php
// pages/create.php
require_once $_SERVER['DOCUMENT_ROOT'] . '/config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: /login?redirect=/create");
    exit;
}

$error = '';
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = trim($_POST['title']);
    $content = $_POST['content']; // HTML allowed, handle XSS on display
    $slug = preg_replace('/[^a-z0-9]+/i', '-', strtolower($title));
    $slug = trim($slug, '-');

    if (empty($title) || empty($content)) {
        $error = "Title and Content are required.";
    } else {
        // Check if slug exists
        $stmt = $pdo->prepare("SELECT id FROM articles WHERE slug = ?");
        $stmt->execute([$slug]);
        if ($stmt->rowCount() > 0) {
            $error = "An article with a similar title already exists. Please choose a different title.";
        } else {
            try {
                $pdo->beginTransaction();
                
                // Insert Article
                $insert_article = $pdo->prepare("INSERT INTO articles (title, slug, content) VALUES (?, ?, ?)");
                $insert_article->execute([$title, $slug, $content]);
                $article_id = $pdo->lastInsertId();

                // Insert First Revision
                $insert_rev = $pdo->prepare("INSERT INTO revisions (article_id, user_id, content) VALUES (?, ?, ?)");
                $insert_rev->execute([$article_id, $_SESSION['user_id'], $content]);

                $pdo->commit();
                header("Location: /wiki/" . $slug);
                exit;
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = "Error creating page. Please try again.";
            }
        }
    }
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/header.php';
?>

<div class="container mx-auto p-4 max-w-5xl">
    <h1 class="text-3xl font-bold mb-6 border-b pb-2">Create New Article</h1>
    
    <?php if($error): ?><div class="bg-red-100 text-red-700 p-3 mb-4 rounded"><?= $error ?></div><?php endif; ?>

    <form method="POST" action="/create">
        <div class="mb-4">
            <label class="block text-gray-800 font-bold mb-2">Article Title</label>
            <input type="text" name="title" class="w-full border border-gray-300 rounded p-2" placeholder="e.g., History of Bengal" required>
        </div>
        
        <div class="mb-4">
            <label class="block text-gray-800 font-bold mb-2">Content</label>
            <textarea id="wiki-editor" name="content" rows="15"></textarea>
        </div>

        <button type="submit" class="bg-blue-600 text-white font-bold py-2 px-6 rounded hover:bg-blue-700">Publish Article</button>
    </form>
</div>

<script src="https://cdn.tiny.cloud/1/5spl6lswyc4hlm9tqklbb5zlyfq42enshhvwk1b0f1sx8ftu/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
<script>
  tinymce.init({
    selector: '#wiki-editor',
    plugins: 'image code table lists link media fullscreen',
    toolbar: 'undo redo | blocks | bold italic | alignleft aligncenter alignright | bullist numlist outdent indent | link image | code fullscreen',
    images_upload_url: '/pages/upload_image.php',
    automatic_uploads: true,
    file_picker_types: 'image',
    setup: function (editor) {
        // Add alt text prompt before upload
        editor.on('OpenWindow', function(e) {
            // Note: In a full production env, you might create a custom file picker dialog to enforce ALT tags securely.
            // TinyMCE handles the 'location' json response from our upload_image.php script automatically.
        });
    }
  });
</script>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php'; ?>
