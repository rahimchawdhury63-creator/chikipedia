<?php
// pages/wiki.php
require_once $_SERVER['DOCUMENT_ROOT'] . '/config/database.php';

$slug = $_GET['slug'] ?? '';
$stmt = $pdo->prepare("SELECT * FROM articles WHERE slug = ?");
$stmt->execute([$slug]);
$article = $stmt->fetch();

if (!$article) {
    $page_title = "Page Not Found";
    require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/header.php';
    echo "<div class='text-center py-20'><h1 class='text-4xl font-bold'>404</h1><p>This page doesn't exist.</p><a href='/create?title=$slug' class='text-blue-600 underline'>Create '$slug' page?</a></div>";
    require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php';
    exit;
}

// Update Views (Simple session protection)
if (!isset($_SESSION['viewed_'.$article['id']])) {
    $pdo->prepare("UPDATE articles SET views = views + 1 WHERE id = ?")->execute([$article['id']]);
    $_SESSION['viewed_'.$article['id']] = true;
}

$page_title = $article['title'] . " - BanglaVerseWiki";
$meta_desc = mb_substr(strip_tags($article['content']), 0, 160) . "...";

require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/header.php';
?>

<article>
    <div class="flex justify-between items-center border-b pb-4 mb-6">
        <h1 class="text-4xl font-serif font-bold"><?= htmlspecialchars($article['title']) ?></h1>
        <a href="/edit/<?= $article['slug'] ?>" class="bg-gray-100 hover:bg-gray-200 px-4 py-2 rounded border text-sm font-bold">
            <i class="fa-solid fa-pen-to-square"></i> Edit Source
        </a>
    </div>

    <div class="wiki-content prose prose-blue max-w-none">
        <?= $article['content'] ?>
    </div>

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "Article",
      "headline": "<?= htmlspecialchars($article['title']) ?>",
      "datePublished": "<?= $article['created_at'] ?>",
      "dateModified": "<?= $article['updated_at'] ?>",
      "author": {"@type": "Organization", "name": "BanglaVerseWiki Community"}
    }
    </script>
    <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [{
    "@type": "ListItem",
    "position": 1,
    "name": "Home",
    "item": "<?= $base_url ?>/"
  },{
    "@type": "ListItem",
    "position": 2,
    "name": "Wiki",
    "item": "<?= $base_url ?>/wiki/"
  },{
    "@type": "ListItem",
    "position": 3,
    "name": "<?= htmlspecialchars($article['title']) ?>",
    "item": "<?= $base_url ?>/wiki/<?= $article['slug'] ?>"
  }]
}
</script>
</article>

</div> <?php require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/sidebar.php'; ?>
<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php'; ?>
