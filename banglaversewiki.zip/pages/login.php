<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/config/database.php';

if (isset($_SESSION['user_id'])) {
    header("Location: /");
    exit;
}

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $login_id = trim($_POST['login_id']); // Can be email or username
    $password = $_POST['password'];

    if (empty($login_id) || empty($password)) {
        $error = "Please enter both fields.";
    } else {
        $stmt = $pdo->prepare("SELECT id, username, password_hash FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$login_id, $login_id]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            header("Location: /");
            exit;
        } else {
            $error = "Invalid username/email or password.";
        }
    }
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/header.php';
?>

<div class="container mx-auto max-w-md mt-10 p-6 bg-white shadow-md rounded">
    <h2 class="text-2xl font-bold mb-4">Login to BanglaVerseWiki</h2>
    
    <?php if($error): ?><div class="bg-red-100 text-red-700 p-2 mb-4 rounded"><?= $error ?></div><?php endif; ?>

    <form method="POST" action="/login">
        <div class="mb-4">
            <label class="block text-gray-700">Username or Email</label>
            <input type="text" name="login_id" class="w-full border rounded p-2" required>
        </div>
        <div class="mb-4">
            <label class="block text-gray-700">Password</label>
            <input type="password" name="password" class="w-full border rounded p-2" required>
        </div>
        <button type="submit" class="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700">Login</button>
    </form>
    <p class="mt-4 text-sm">Don't have an account? <a href="/register" class="text-blue-600">Register here</a>.</p>
</div>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php'; ?>
