<?php
// includes/sidebar.php
// Get Top Articles by Score
$side_stmt = $pdo->query("SELECT title, slug FROM articles ORDER BY score DESC LIMIT 5");
$top_articles = $side_stmt->fetchAll();

// Get New Articles
$new_stmt = $pdo->query("SELECT title, slug FROM articles ORDER BY created_at DESC LIMIT 5");
$new_articles = $new_stmt->fetchAll();
?>
<aside class="w-full md:w-1/4 space-y-6">
    <div class="bg-white p-4 rounded shadow-sm border-t-4 border-blue-600">
        <h3 class="font-bold text-lg mb-3"><i class="fa-solid fa-fire text-orange-500"></i> Trending</h3>
        <ul class="text-sm space-y-2">
            <?php foreach($top_articles as $art): ?>
                <li><a href="/wiki/<?= $art['slug'] ?>" class="text-blue-600 hover:underline"><?= htmlspecialchars($art['title']) ?></a></li>
            <?php endforeach; ?>
        </ul>
    </div>

    <div class="bg-white p-4 rounded shadow-sm">
        <h3 class="font-bold text-lg mb-3">New Articles</h3>
        <ul class="text-sm space-y-2">
            <?php foreach($new_articles as $art): ?>
                <li><a href="/wiki/<?= $art['slug'] ?>" class="text-blue-600 hover:underline"><?= htmlspecialchars($art['title']) ?></a></li>
            <?php endforeach; ?>
        </ul>
    </div>

    <div class="bg-gray-200 p-4 rounded text-xs text-gray-600">
        BanglaVerseWiki is an independent platform. Every edit helps the community grow.
    </div>
</aside>
