<?php
// index.php
require_once $_SERVER['DOCUMENT_ROOT'] . '/config/database.php';

// Ranking Algorithm Execution
// score = (views * 1 + likes * 5 + edit_count * 2) / (days_since_creation + 1)
$pdo->query("UPDATE articles SET score = (views + (likes * 5) + (edit_count * 2)) / (DATEDIFF(NOW(), created_at) + 1)");

$top_query = $pdo->query("SELECT * FROM articles ORDER BY score DESC LIMIT 6");
$top_articles = $top_query->fetchAll();

require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/header.php';
?>

<div class="text-center py-10">
    <h1 class="text-5xl font-bold text-gray-800 mb-4">Welcome to BanglaVerseWiki</h1>
    <p class="text-xl text-gray-600 mb-8">The free encyclopedia that anyone can edit.</p>
    
    <form action="/wiki.php" method="GET" class="max-w-2xl mx-auto flex gap-2">
        <input type="text" name="slug" placeholder="Search for an article..." class="w-full p-4 rounded-l-lg border-2 border-blue-600 outline-none">
        <button type="submit" class="bg-blue-600 text-white px-8 rounded-r-lg font-bold">Search</button>
    </form>
</div>

<h2 class="text-2xl font-bold mb-6 border-b pb-2">Trending Today</h2>
<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
    <?php foreach($top_articles as $art): ?>
        <div class="bg-gray-50 p-6 rounded border hover:shadow-md transition">
            <h3 class="text-xl font-bold text-blue-700 mb-2">
                <a href="/wiki/<?= $art['slug'] ?>"><?= htmlspecialchars($art['title']) ?></a>
            </h3>
            <p class="text-gray-600 text-sm mb-4">
                <?= mb_substr(strip_tags($art['content']), 0, 150) ?>...
            </p>
            <div class="flex items-center text-xs text-gray-400 space-x-4">
                <span><i class="fa-solid fa-eye"></i> <?= $art['views'] ?></span>
                <span><i class="fa-solid fa-pen"></i> <?= $art['edit_count'] ?> edits</span>
            </div>
        </div>
    <?php endforeach; ?>
</div>

</div> <?php require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/sidebar.php'; ?>
<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php'; ?>
