<?php
// pages/edit.php
require_once $_SERVER['DOCUMENT_ROOT'] . '/config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: /login?redirect=" . urlencode($_SERVER['REQUEST_URI']));
    exit;
}

$slug = isset($_GET['slug']) ? htmlspecialchars($_GET['slug']) : '';
$error = '';
$success = '';

// Fetch Article
$stmt = $pdo->prepare("SELECT * FROM articles WHERE slug = ?");
$stmt->execute([$slug]);
$article = $stmt->fetch();

if (!$article) {
    header("Location: /create?title=" . urlencode($slug));
    exit;
}

// Handle Rollback
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['rollback_id'])) {
    $rev_id = (int)$_POST['rollback_id'];
    $rev_stmt = $pdo->prepare("SELECT content FROM revisions WHERE id = ? AND article_id = ?");
    $rev_stmt->execute([$rev_id, $article['id']]);
    $revision = $rev_stmt->fetch();

    if ($revision) {
        $_POST['content'] = $revision['content']; // Fake a content submission for the rollback
    }
}

// Handle Edit Submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['content'])) {
    // Spam protection: Limit edits per minute (basic implementation)
    $spam_check = $pdo->prepare("SELECT created_at FROM revisions WHERE user_id = ? ORDER BY created_at DESC LIMIT 1");
    $spam_check->execute([$_SESSION['user_id']]);
    $last_edit = $spam_check->fetch();
    
    if ($last_edit && (time() - strtotime($last_edit['created_at']) < 30)) {
        $error = "Please wait at least 30 seconds between edits to prevent spam.";
    } else {
        $new_content = $_POST['content'];
        
        try {
            $pdo->beginTransaction();
            
            // Update Article (Increment edit_count for Ranking)
            $update = $pdo->prepare("UPDATE articles SET content = ?, edit_count = edit_count + 1 WHERE id = ?");
            $update->execute([$new_content, $article['id']]);
            
            // Save Revision
            $insert_rev = $pdo->prepare("INSERT INTO revisions (article_id, user_id, content) VALUES (?, ?, ?)");
            $insert_rev->execute([$article['id'], $_SESSION['user_id'], $new_content]);
            
            $pdo->commit();
            header("Location: /wiki/" . $slug);
            exit;
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "Error saving changes.";
        }
    }
}

// Fetch Revision History
$history_stmt = $pdo->prepare("
    SELECT r.id, r.created_at, u.username 
    FROM revisions r 
    JOIN users u ON r.user_id = u.id 
    WHERE r.article_id = ? 
    ORDER BY r.created_at DESC
");
$history_stmt->execute([$article['id']]);
$revisions = $history_stmt->fetchAll();

require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/header.php';
?>

<div class="container mx-auto p-4 max-w-6xl flex flex-col md:flex-row gap-6">
    <div class="md:w-3/4">
        <h1 class="text-3xl font-bold mb-2">Editing: <?= htmlspecialchars($article['title']) ?></h1>
        <p class="text-sm text-gray-500 mb-6">Editing as <?= htmlspecialchars($_SESSION['username']) ?></p>
        
        <?php if($error): ?><div class="bg-red-100 text-red-700 p-3 mb-4 rounded"><?= $error ?></div><?php endif; ?>

        <form method="POST" action="/edit/<?= $slug ?>">
            <div class="mb-4">
                <textarea id="wiki-editor" name="content" rows="20"><?= htmlspecialchars($article['content']) ?></textarea>
            </div>
            <button type="submit" class="bg-green-600 text-white font-bold py-2 px-6 rounded hover:bg-green-700">Save Changes</button>
            <a href="/wiki/<?= $slug ?>" class="ml-4 text-gray-600 hover:underline">Cancel</a>
        </form>
    </div>

    <div class="md:w-1/4 bg-gray-50 p-4 border rounded">
        <h3 class="font-bold text-lg border-b pb-2 mb-4">Revision History</h3>
        <div class="overflow-y-auto max-h-96">
            <?php foreach($revisions as $index => $rev): ?>
                <div class="mb-3 p-2 bg-white border rounded text-sm">
                    <p class="font-bold"><?= htmlspecialchars($rev['username']) ?></p>
                    <p class="text-xs text-gray-500"><?= date('M j, Y H:i', strtotime($rev['created_at'])) ?></p>
                    
                    <?php if ($index > 0): // Don't show rollback for current version ?>
                        <form method="POST" action="/edit/<?= $slug ?>" class="mt-2" onsubmit="return confirm('Are you sure you want to rollback to this version?');">
                            <input type="hidden" name="rollback_id" value="<?= $rev['id'] ?>">
                            <button type="submit" class="text-blue-600 hover:underline text-xs">Rollback to this</button>
                        </form>
                    <?php else: ?>
                        <span class="text-green-600 text-xs font-bold mt-2 block">Current Version</span>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<script src="https://cdn.tiny.cloud/1/5spl6lswyc4hlm9tqklbb5zlyfq42enshhvwk1b0f1sx8ftu/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
<script>
  tinymce.init({
    selector: '#wiki-editor',
    plugins: 'image code table lists link media fullscreen',
    toolbar: 'undo redo | blocks | bold italic | alignleft aligncenter alignright | bullist numlist outdent indent | link image | code fullscreen',
    images_upload_url: '/pages/upload_image.php',
    automatic_uploads: true,
    file_picker_types: 'image'
  });
</script>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php'; ?>
