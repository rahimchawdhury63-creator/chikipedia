<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/config/database.php';

$error = '';
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim(htmlspecialchars($_POST['username']));
    $email = trim(filter_var($_POST['email'], FILTER_SANITIZE_EMAIL));
    $password = $_POST['password'];

    if (empty($username) || empty($email) || empty($password)) {
        $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        
        if ($stmt->rowCount() > 0) {
            $error = "Username or email already exists.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $insert = $pdo->prepare("INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)");
            
            if ($insert->execute([$username, $email, $hashed_password])) {
                $success = "Registration successful! You can now <a href='/login'>login</a>.";
            } else {
                $error = "Something went wrong. Please try again.";
            }
        }
    }
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/header.php';
?>

<div class="container mx-auto max-w-md mt-10 p-6 bg-white shadow-md rounded">
    <h2 class="text-2xl font-bold mb-4">Create an Account</h2>
    
    <?php if($error): ?><div class="bg-red-100 text-red-700 p-2 mb-4 rounded"><?= $error ?></div><?php endif; ?>
    <?php if($success): ?><div class="bg-green-100 text-green-700 p-2 mb-4 rounded"><?= $success ?></div><?php endif; ?>

    <form method="POST" action="/register">
        <div class="mb-4">
            <label class="block text-gray-700">Username</label>
            <input type="text" name="username" class="w-full border rounded p-2" required>
        </div>
        <div class="mb-4">
            <label class="block text-gray-700">Email</label>
            <input type="email" name="email" class="w-full border rounded p-2" required>
        </div>
        <div class="mb-4">
            <label class="block text-gray-700">Password</label>
            <input type="password" name="password" class="w-full border rounded p-2" required>
        </div>
        <button type="submit" class="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700">Register</button>
    </form>
    <p class="mt-4 text-sm">Already have an account? <a href="/login" class="text-blue-600">Login here</a>.</p>
</div>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php'; ?>
