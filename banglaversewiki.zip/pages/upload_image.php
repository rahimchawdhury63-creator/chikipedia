<?php
// pages/upload_image.php
require_once $_SERVER['DOCUMENT_ROOT'] . '/config/database.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'You must be logged in to upload images.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $alt_text = isset($_POST['alt_text']) ? trim($_POST['alt_text']) : 'wiki_image_' . time();
    
    // Create a URL-safe filename from the alt text
    $safe_alt = preg_replace('/[^a-z0-9]+/', '_', strtolower($alt_text));
    $safe_alt = trim($safe_alt, '_');
    $filename = $safe_alt . '.webp';
    $target_dir = $_SERVER['DOCUMENT_ROOT'] . '/img/wiki/';
    $target_file = $target_dir . $filename;

    // Ensure directory exists
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0755, true);
    }

    $file_type = mime_content_type($_FILES['file']['tmp_name']);
    $source = $_FILES['file']['tmp_name'];
    $image = null;

    // Load image based on type
    switch ($file_type) {
        case 'image/jpeg':
        case 'image/jpg':
            $image = imagecreatefromjpeg($source);
            break;
        case 'image/png':
            $image = imagecreatefrompng($source);
            imagepalettetotruecolor($image);
            imagealphablending($image, true);
            imagesavealpha($image, true);
            break;
        case 'image/gif':
            $image = imagecreatefromgif($source);
            break;
        case 'image/webp':
            $image = imagecreatefromwebp($source);
            break;
        default:
            echo json_encode(['error' => 'Unsupported image format.']);
            exit;
    }

    if ($image !== false) {
        // Save as WEBP with 80% quality
        if (imagewebp($image, $target_file, 80)) {
            imagedestroy($image);
            
            // Save to database
            $stmt = $pdo->prepare("INSERT INTO images (user_id, alt_text, file_path) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE file_path = ?");
            $url_path = '/img/wiki/' . $filename;
            $stmt->execute([$_SESSION['user_id'], $alt_text, $url_path, $url_path]);

            echo json_encode(['location' => $url_path]); // 'location' is what TinyMCE expects
            exit;
        }
    }
    echo json_encode(['error' => 'Failed to process image.']);
}
?>
