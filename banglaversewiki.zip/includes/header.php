<?php
// includes/header.php
require_once $_SERVER['DOCUMENT_ROOT'] . '/config/database.php';

// SEO Logic
$page_title = $page_title ?? "BanglaVerseWiki - The Open Encyclopedia";
$meta_desc = $meta_desc ?? "BanglaVerseWiki is a community-driven encyclopedia for sharing knowledge.";
$canonical = "https://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?></title>
    <meta name="description" content="<?= $meta_desc ?>">
    <meta name="google-site-verification" content="2pHt_phns6GkO5b7NdMWpt9wJypEjRsfSnSC6YNvCjY" />
    <!-- Favicon -->
<link rel="icon" href="/img/icon/favicon.ico" type="image/x-icon">
<link rel="shortcut icon" href="/img/icon/favicon.ico">
<meta property="og:site_name" content="BanglaVerseWiki" />

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "name": "BanglaVerseWiki",
  "alternateName": ["Bangla Verse Wiki", "BanglaVerse Wiki"],
  "url": "https://banglaversewiki.unaux.com/"
}
</script>


<!-- PNG Favicons -->
<link rel="icon" type="image/png" sizes="192x192" href="/img/icon/android-chrome-192x192.png">
<link rel="icon" type="image/png" sizes="512x512" href="/img/icon/android-chrome-512x512.png">


<!-- Android / PWA Support -->
<link rel="manifest" href="/manifest.json">

<!-- Theme Color (for mobile browser UI) -->
<meta name="theme-color" content="#ffffff">
    <link rel="icon" href="/img/icon/favicon.ico">
    <link rel="apple-touch-icon" sizes="180x180" href="/img/icon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/img/icon/favicon-32x32.png">
 <link href=
"https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css" 
        rel="stylesheet">
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=Lora:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">
<style>
/* ==========================================================================
   BanglaVerseWiki - Ultimate Vibrant & Responsive Theme
   ========================================================================== */

:root {
    /* Vibrant Color Palette & Gradients */
    --primary-color: #2563eb; /* Blue 600 */
    --primary-glow: rgba(37, 99, 235, 0.4);
    --vibrant-gradient: linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%);
    --surface-glass: rgba(255, 255, 255, 0.85);
    
    /* Backgrounds & Text */
    --bg-main: #f8fafc; /* Slate 50 */
    --text-dark: #0f172a;
    --text-muted: #64748b;
    
    /* Shadows & Transitions */
    --shadow-soft: 0 10px 40px -10px rgba(0,0,0,0.08);
    --shadow-hover: 0 20px 40px -10px rgba(37, 99, 235, 0.15);
    --transition-smooth: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
}

body {
    background-color: var(--bg-main);
    color: var(--text-dark);
    font-family: 'Inter', system-ui, -apple-system, sans-serif;
    scroll-behavior: smooth;
    overflow-x: hidden;
}

/* =========================================
   1. Custom Premium Scrollbar
   ========================================= */
::-webkit-scrollbar { width: 10px; height: 10px; }
::-webkit-scrollbar-track { background: #f1f5f9; }
::-webkit-scrollbar-thumb { 
    background: #cbd5e1; 
    border-radius: 5px; 
    border: 2px solid #f1f5f9;
}
::-webkit-scrollbar-thumb:hover { background: #94a3b8; }

/* =========================================
   2. Glassmorphism Header (Sticky Nav)
   ========================================= */
nav.fixed {
    background: var(--surface-glass) !important;
    backdrop-filter: blur(16px);
    -webkit-backdrop-filter: blur(16px);
    border-bottom: 1px solid rgba(255, 255, 255, 0.3);
    box-shadow: 0 4px 30px rgba(0, 0, 0, 0.03);
    transition: var(--transition-smooth);
}

/* Mobile Nav Hide/Show Logic (Toggled via JS) */
.nav-links-container {
    transition: max-height 0.4s ease, opacity 0.4s ease;
}
@media (max-width: 768px) {
    .nav-links-container {
        display: none;
        flex-direction: column;
        width: 100%;
        position: absolute;
        top: 64px; left: 0;
        background: var(--surface-glass);
        backdrop-filter: blur(16px);
        padding: 1rem;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
    }
    .nav-links-container.active {
        display: flex !important;
        animation: slideDown 0.3s ease forwards;
    }
    .nav-links-container a {
        margin-bottom: 0.5rem;
        width: 100%;
        text-align: center;
    }
}

/* =========================================
   3. Homepage & Cards (Index.php)
   ========================================= */
/* The Hero Search Input */
input[name="slug"] {
    transition: var(--transition-smooth);
    background: #ffffff;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
}
input[name="slug"]:focus {
    box-shadow: 0 0 0 4px var(--primary-glow);
    border-color: var(--primary-color);
    transform: translateY(-2px);
}

/* Trending Cards Grid */
.grid > div {
    background: #ffffff;
    border-radius: 16px;
    border: 1px solid #e2e8f0;
    padding: 1.5rem;
    transition: var(--transition-smooth);
    box-shadow: var(--shadow-soft);
    position: relative;
    overflow: hidden;
}
.grid > div::before {
    content: ''; position: absolute; top: 0; left: 0; width: 100%; height: 4px;
    background: var(--vibrant-gradient);
    transform: scaleX(0); transform-origin: left;
    transition: transform 0.4s ease;
}
.grid > div:hover {
    transform: translateY(-5px);
    box-shadow: var(--shadow-hover);
    border-color: transparent;
}
.grid > div:hover::before { transform: scaleX(1); }

/* =========================================
   4. Layout: Main Content & Sidebar
   ========================================= */
main {
    background: #ffffff;
    border-radius: 20px;
    box-shadow: var(--shadow-soft);
    border: 1px solid rgba(255, 255, 255, 0.6);
}

/* Sticky Sidebar for Desktop */
@media (min-width: 768px) {
    aside {
        position: sticky;
        top: 85px; /* Sits just below the header */
        height: fit-content;
    }
}
aside > div {
    border-radius: 16px;
    box-shadow: var(--shadow-soft);
    transition: var(--transition-smooth);
}
aside > div:hover {
    box-shadow: var(--shadow-hover);
}

/* =========================================
   5. Wiki Articles (Readability & Typography)
   ========================================= */
.wiki-content {
    font-family: 'Lora', serif; /* Serif is best for long-form reading */
    font-size: 1.15rem;
    line-height: 1.8;
    color: #334155;
}
.wiki-content h1, .wiki-content h2, .wiki-content h3 {
    font-family: 'Inter', sans-serif;
    color: #0f172a;
    font-weight: 800;
    margin-top: 2em;
    position: relative;
}
/* Beautiful Link Underlines */
.wiki-content a {
    color: var(--primary-color);
    text-decoration: none;
    background-image: linear-gradient(120deg, #dbeafe 0%, #dbeafe 100%);
    background-repeat: no-repeat;
    background-size: 100% 0.2em;
    background-position: 0 100%;
    transition: background-size 0.25s ease-in;
    font-weight: 600;
}
.wiki-content a:hover { background-size: 100% 100%; }

/* =========================================
   6. UI Elements (Buttons, Alerts, Progress)
   ========================================= */
button[type="submit"], .bg-blue-600 {
    background: var(--vibrant-gradient);
    background-size: 200% auto;
    border: none;
    transition: 0.4s ease-in-out;
}
button[type="submit"]:hover, .bg-blue-600:hover {
    background-position: right center;
    box-shadow: 0 8px 20px var(--primary-glow);
    transform: translateY(-2px);
}

#reading-progress {
    position: fixed; top: 0; left: 0; width: 0%; height: 4px;
    background: var(--vibrant-gradient);
    z-index: 9999; transition: width 0.1s ease;
}

/* =========================================
   7. Animations
   ========================================= */
@keyframes slideDown {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}
@keyframes fadeUp {
    from { opacity: 0; transform: translateY(30px); }
    to { opacity: 1; transform: translateY(0); }
}
.fade-up-element {
    animation: fadeUp 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards;
}

 </style>
    
</head>
<body class="bg-gray-100 font-sans leading-normal tracking-normal">

<nav class="bg-white border-b border-gray-200 fixed w-full z-30 top-0">
    <div class="max-w-7xl mx-auto px-4">
        <div class="flex justify-between h-16">
            <div class="flex items-center">
                <a href="/" class="text-2xl font-bold text-blue-700 flex items-center">
                    <i class="fa-solid fa-globe-asia mr-2"></i> BanglaVerseWiki
                </a>
            </div>
            <div class="flex items-center space-x-4">
                <a href="/" class="text-gray-700 hover:text-blue-600">Home</a>
                <a href="/create" class="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700">+ Create</a>
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="/user/<?= $_SESSION['username'] ?>" class="text-gray-700 font-medium">@<?= $_SESSION['username'] ?></a>
                    <a href="/logout" class="text-red-500 text-sm">Logout</a>
                <?php else: ?>
                    <a href="/login" class="text-gray-700">Login</a>
                    <a href="/register" class="border border-blue-600 text-blue-600 px-3 py-1 rounded">Sign Up</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<div class="pt-20 max-w-7xl mx-auto px-4 flex flex-col md:flex-row gap-8">
    <main class="w-full md:w-3/4 bg-white p-6 rounded shadow-sm min-h-screen">
